import configparser
import os
import shutil
import subprocess
import sys
import time
import traceback
from MyLog import *
# from MyLog import ConfigVar.config_path_hash
from PyQt5.QtCore import QThread


class ProjectMess:
    def __init__(self):
        self.id = ''
        self.name = ''
        self.path = ''
        self.cmd = ''
        self.ctime = ''
        self.chip = ''
        self.type = ''
        self.demo = []

    def set(self,project):
        self.id =project.id
        self.name = project.name
        self.path = project.path
        self.cmd = project.cmd
        self.ctime = project.ctime
        self.chip = project.chip
        self.type = project.type
        self.demo = project.demo

    def show(self):
        print("ConfigVar.project.id = " + self.id)
        print("ConfigVar.project.name = " + self.name)
        print("ConfigVar.project.path = " + self.path)
        print("ConfigVar.project.ctime = " + self.ctime)
        print("ConfigVar.project.cmd = " + self.cmd)
        print("ConfigVar.project.chip = " + self.chip)
        print("ConfigVar.project.type = " + self.type)
        print("ConfigVar.project.demo = ", end="")
        print(self.demo)
        info("id =(%s) name =(%s) path=(%s) ctime=(%s) cmd=(%s) chip=(%s) type=(%s) demo=(...)",
             self.id,self.name,self.path,self.ctime,self.cmd,self.chip,self.type)

    def write(self, path):
        try:
            config = configparser.ConfigParser()
            if (os.path.exists(path)):
                config.read(path)
                print("打开project.ini")
                info("打开project.ini")
            else:
                f = open(path, "w")
                str = "[name]\n[path]\n[ctime]\n[cmd]\n[chip]\n[type]\n[demo]"
                f.write(str)
                f.close()
                print("创建project.ini")
                info("创建project.ini")
                config.read(path)
            config.set('name', self.id, self.name)
            config.set('path', self.id, self.path)
            config.set('ctime', self.id, self.ctime)
            config.set('cmd', self.id, self.cmd)
            config.set('chip', self.id, self.chip)
            config.set('type', self.id, self.type)
            config.set('demo', self.id, ' '.join(self.demo))
            with open(path, 'w') as cf:
                config.write(cf)
        except Exception as e:
            traceback.print_exc()
            error(e)
    def read(self, id, config):
        self.id = id
        self.name = config.get('name', self.id)
        self.path = config.get('path', self.id)
        self.ctime = config.get('ctime', self.id)
        self.cmd = config.get('cmd', self.id)
        self.chip = config.get('chip', self.id)
        self.type = config.get('type', self.id)
        str = config.get('demo', self.id)
        self.demo = str.split(' ')
        self.cmd = ConfigVar.keilUV4_path+ ' '+ self.cmd.split(' ')[1]
        print(self.cmd)

    def delete(self, path):
            print(self.path)
            str = self.path.replace('/', '\\')
            print(str)
            if (os.path.exists(str)):
                shutil.rmtree(str)
                print("success removed " + str)
                info("success removed " + str)
            else:
                print("文件删除失败，路径不存在!  %s",str)
                info("文件删除失败，路径不存在!  %s",str)
            config = configparser.ConfigParser()
            config.read(path)
            config.remove_option('name', self.id)
            config.remove_option('path', self.id)
            config.remove_option('ctime', self.id)
            config.remove_option('cmd', self.id)
            config.remove_option('chip', self.id)
            config.remove_option('type', self.id)
            config.remove_option('demo', self.id)
            with open(path, 'w') as cf:
                config.write(cf)
            print("配置文件移除项目成功!    %s",str)
            info("配置文件移除项目成功!    %s",str)


    def clear(self):
        self.id = 0
        self.name = ''
        self.path = ''
        self.cmd = ''
        self.ctime = ''
        self.chip = ''
        self.type = ''
        self.demo = []


class ConfigVar:

    config_path_hash = GetPath('config.ini')
    project_path_hash = GetPath('project.ini')
    language = 'en'
    projectchip = ''
    mainWindow = None
    python_path = 'python.exe'
    keilUV4_path = ''
    path_flag = 'false'
    projectname = ''
    projectpath = ''
    project = ProjectMess()
    mainwindowsize = ''
    ID = 1
    uvprojxmap = {'CDC_HID_Composite': 'usbd_composite_cdc_hid.uvprojx',
                  'Custom_HID': 'usbd_custom_hid.uvprojx',
                  'HID': 'usbd_hid.uvprojx',
                  'MSC': 'usbd_msc.uvprojx',
                  'Virtual_COM_Port': 'usbd_vcp.uvprojx'}
    demo_introduce = {
        'ACMP_DAC': 'ACMP:当比较器的比较结果为1时，串口输出POS > NEG，并输出通道0和通道1的值；当比较器的比较结果为0时，串口输出POS < NEG，并输出通道0和通道1的值；',
        'ADC_ADC_Watchdog': 'ADC Watchdog：当转换电压值超过阈值时打印AWD Interrupt；当转换完成时，打印通道0的ADC转换值。',
        'ADC_Chip_Temperature': 'Chip Temperature:检测内部温度，每一秒钟打印一次。',
        'ADC_Pin_Interrupt': 'pin-中断：每100ms打印一次通道0和通道1的ADC转化值。',
        'ADC_Pin_Loop': 'pin-loop：每50ms打印一次通道0和通道1的ADC转化值。',
        'ADC_Trigger': 'Trigger:每5s触发一次ADC转换，并打印通道0和通道1的值。',
        'DAC_DAC0_DAC1': 'DAC:通道0和通道1以4s为一周期，同步输出从0V到3.3V再到0V的三角波。',
        'DeepSleep_DeepSleep': 'Deep Sleep:蓝色LED200和红色LED201，以300ms为一周期（明暗各150ms）闪烁三秒后进入深度睡眠模式，蓝色LED200与红色LED201长亮。',
        'DeepSleep_PowerDown': 'PowerDown:蓝色LED200和红色LED201，以300ms为一周期（明暗各150ms）闪烁三秒后进入掉电模式，蓝色LED200与红色LED201灭。',
        'FLASH_IAP': 'FLASH:擦除APROM_ADDR中数据，再写入512字节后读出比较，若写入数据不等于读出数据则打印Programm APROM ........................... Failed!\n若写入数据等于读出数据，待读写完成后打印APROM Test.................................... OK!\n擦除LDROM_ADDR中数据，再写入512字节后读出比较，若写入数据不等于读出数据则打印Programm LDROM ........................... Failed!\n若写入数据等于读出数据，待读写完成后打印LDROM Test.................................... OK!',
        'GPIO_LED_and_Key': 'GPIO:红色LED201与蓝色LED200每60ms闪烁一次（明暗各30ms），每按一次WAKEUP键其闪烁周期为上一周期的1.25倍，最高2s闪烁一次。',
        'I2C_EEPROM': 'I2C:读写缓冲区的值并打印，若读写缓冲区的值不相等则打印Not Match，若相等则打印Match',
        'IWDG_Reset': 'IWDG:蓝色LED200以440ms为一周期（明暗各220ms）闪烁，每220ms重新装载一次计数器。',
        'MCPWM_Complementary_waveform': 'MCPWM:通道0(GPIO2_6,GPIO3_1)输出周期为20us，占空比为60%，死区时间为1us的方波；\n通道1（GPIO2.0,GPIO3.2）输出周期为20us，占空比为40%的方波；\n通道2（GPIO2.1,GPIO3.3）输出周期为10us，占空比为60%，死区时间为1us的方波。',
        'RTC_Time': 'RTC:中断发生时，屏幕输出HZ和Alarm的中断时间。',
        'SPI_SPI_FLASH': 'SPI:打印出SPI FLASH的ID[0]和ID[1]的值，打印读缓冲区的值，打印写入写缓冲区的值。',
        'TIMER_Breathing_Light': 'TIMER:Breathing Light:蓝色LED200的灯光以8S为一周期进行进行强-弱-强的类似呼吸的变化。',
        'TIMER_PWM_and_Capture': 'PWM and Capture:通道0输出20000个周期为10us，占空比为50%的PWM波，Timer0的Capture1捕获到20000个脉冲后产生中断。',
        'TIMER_Timer_and_PWM': 'Timer and PWM:通道1输出周期为10us，占空比由少变多再变少；通道0为定时器，每1ms产生一次中断。',
        'USART_RX_and_TX': 'USART:在PC串口终端输入数据，中断接收，再发送到PC。',
        'WWDG_Reset': 'WWDG_Reset:当64<计数值<80时，窗口看门狗的计数值会被更新，否则将产生复位；蓝色LED200以160ms为一周期闪烁（明暗各80ms），每80ms更新一次计数器。',

        'CDC_HID_Composite': 'CDC_HID_Composite：现象--综合了Custom HID和Virtual_COM_Port\nPS--需要手动安装驱动MIC_HID_CDC_Driver.inf',
        'Custom_HID': 'Custom HID：现象--每次上报64个字节',
        'HID': 'HID：现象--鼠标不停的左右抖动，每ms上报一次\nPS--如果要求1秒钟1000个包全部上报成功，必须使用外部晶振',
        'MSC': 'MSC：现象--生成一个8MB大小的U盘\nPS--开发板上可能不是8MB大小的SPI FLASH',
        'Virtual_COM_Port': 'Virtual_COM_Port:现象--PC产生一个串口\nPS--需要手动安装驱动MIC_CDC_Driver.inf'
    }

    chip_introduce = {
        'VTM071X':'VTM071X 运行频率可以达到 84MHZ，工作电压 2.0V ~ 5.5V,X 内嵌 128K 字节的 Flash 存储器，其中用户可用空间为 120KB，以及 16K 字节的 SRAM 存储器,包含许多系统级外设功能，如高速通用 I/O 端口，4 通道DMA,Cordic 运算单元，USART，SPI，I2C，PWM，Motor-PWM，ADC，DAC，模拟比较器，看门狗定时器，RTC，欠压检测器等' ,
        'VTM32030X':'VTM32030X 运行频率可以达到 84MHZ，工作电压 2.0V ~ 5.5V,X 内嵌 128K 字节的 Flash 存储器，其中用户可用空间为 120KB，以及 16K 字节的 SRAM 存储器,包含许多系统级外设功能，如高速通用 I/O 端口，4 通道DMA,Cordic 运算单元，USART，SPI，I2C，PWM，Motor-PWM，ADC，DAC，模拟比较器，看门狗定时器，RTC，欠压检测器等'
    }

    def readconf(self):
        # 读取配置文件
        try:

            config = configparser.ConfigParser()
            if os.path.exists(ConfigVar.config_path_hash):
                config.read(ConfigVar.config_path_hash)
                ConfigVar.python_path = config.get('installation', 'python_path')
                ConfigVar.keilUV4_path = config.get('installation', 'keilUV4_path')
                ConfigVar.path_flag = config.get('installation', 'path_flag')
                ConfigVar.project.name = config.get('installation', 'projectname')
                ConfigVar.projectname = ConfigVar.project.name
                ConfigVar.project.path = config.get('installation', 'projectpath')
                ConfigVar.projectpath = ConfigVar.project.path
                ConfigVar.language = config.get('installation', 'language')
                ConfigVar.ID = int(config.get('installation', 'ID'))
            else:
                config.add_section('installation')
                config.set('installation', 'python_path','python.exe')
                config.set('installation', 'keilUV4_path','')
                config.set('installation', 'path_flag', 'flase')
                config.set('installation', 'projectname','Test1')
                config.set('installation', 'projectpath','')
                config.set('installation', 'language', 'en')
                config.set('installation', 'ID', '0')
                with open(ConfigVar.config_path_hash,'w') as f:
                    config.write(f)

        except Exception as e:
            traceback.print_exc()
            error(e)

class WorkThread(QThread):
    def __int__(self):
        # 初始化函数
        super(WorkThread, self).__init__()

    def run(self, str):
        try:
            str = str.replace('/','\\')
            print(str + "------------------项目线程开始-----------------")

            ConfigVar.project.cmd = str
            ConfigVar.project.ctime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            ConfigVar.project.show()
            ConfigVar.project.write(ConfigVar.project_path_hash)
            print("配置文件保存成功!")
            info("配置文件保存成功!")

            if sys.platform == "win32":
                import ctypes
                ctypes.windll.kernel32.SetDllDirectoryA(None)
            subprocess.Popen([ConfigVar.keilUV4_path,str.split('.exe ')[1]], start_new_session=True )
            print("--项目线程开始-->  "+ConfigVar.keilUV4_path+'  '+str.split('.exe ')[1])
            info("--项目线程开始-->(%s) (%s)",ConfigVar.keilUV4_path,str.split('.exe ')[1])
        except Exception as e:
            traceback.print_exc()
            error(e)

class CmdThread(QThread):
    def __int__(self):
        # 初始化函数
        super(CmdThread, self).__init__()

    def run(self, str):
        try:
            str = str.replace("/", "\\")
            print("------------------cmd线程开始--(%s)",str)
            info("------------------cmd线程开始--(%s)",str)

            os.system('chcp 65001')  # 文件名包含中文
            os.popen(str)
        except Exception as e:
            traceback.print_exc()
            error(e)
