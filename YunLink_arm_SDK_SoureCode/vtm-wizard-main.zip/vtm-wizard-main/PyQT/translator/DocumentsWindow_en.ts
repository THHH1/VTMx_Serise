<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../UI/doc.py" line="63"/>
        <source>Documents</source>
        <translation>Documents</translation>
    </message>
    <message>
        <location filename="../UI/doc.py" line="64"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../UI/doc.py" line="65"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
</context>
</TS>
