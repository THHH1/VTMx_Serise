<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>About</name>
    <message>
        <location filename="../UI/about.py" line="56"/>
        <source>About</source>
        <translation type="unfinished">About</translation>
    </message>
    <message>
        <location filename="../UI/about.py" line="57"/>
        <source>OK</source>
        <translation type="unfinished">OK</translation>
    </message>
    <message>
        <location filename="../UI/about.py" line="58"/>
        <source>Copyright(c) by</source>
        <translation type="unfinished">Copyright(c) by</translation>
    </message>
</context>
</TS>
