<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>Form</name>
    <message>
        <location filename="../UI/importdemo.py" line="364"/>
        <source>Import Project</source>
        <translation>Import Project</translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="365"/>
        <source>CDC_HID_Composite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="366"/>
        <source>Custom_HID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="367"/>
        <source>HID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="368"/>
        <source>MSC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="369"/>
        <source>Virtual_COM_Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="223"/>
        <source>    Cancel</source>
        <translation type="obsolete">Cancel</translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="371"/>
        <source>chip</source>
        <translation>chip</translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="372"/>
        <source>TIMER_Timer_and_PWM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="373"/>
        <source>ACMP_DAC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="374"/>
        <source>I2C_EEPROM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="375"/>
        <source>FLASH_IAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="376"/>
        <source>ADC_Chip_Temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="377"/>
        <source>ADC_Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="378"/>
        <source>TIMER_Breathing_Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="379"/>
        <source>ADC_Pin_Loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="380"/>
        <source>TIMER_PWM_and_Capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="381"/>
        <source>DeepSleep_PowerDown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="382"/>
        <source>MCPWM_Complementary_waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="383"/>
        <source>USART_RX_and_TX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="384"/>
        <source>ADC_ADC_Watchdog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="385"/>
        <source>DAC_DAC0_DAC1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="386"/>
        <source>GPIO_LED_and_Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="387"/>
        <source>ADC_Pin_Interrupt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="388"/>
        <source>SPI_SPI_FLASH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="389"/>
        <source>RTC_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="390"/>
        <source>DeepSleep_DeepSleep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="391"/>
        <source>IWDG_Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="392"/>
        <source>WWDG_Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="393"/>
        <source>Choose Modeules</source>
        <translation>Choose Modeules</translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="394"/>
        <source>V1.35</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="395"/>
        <source>USBV1.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="396"/>
        <source>modular</source>
        <translation>modular</translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="397"/>
        <source>Next</source>
        <translation>Next</translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="370"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../UI/importdemo.py" line="398"/>
        <source>Back</source>
        <translation>Back</translation>
    </message>
</context>
</TS>
