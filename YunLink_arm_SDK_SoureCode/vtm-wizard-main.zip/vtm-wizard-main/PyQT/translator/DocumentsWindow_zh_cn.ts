<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../UI/doc.py" line="63"/>
        <source>Documents</source>
        <translation>文档</translation>
    </message>
    <message>
        <location filename="../UI/doc.py" line="64"/>
        <source>OK</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../UI/doc.py" line="65"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
</TS>
