<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>YunWizard</name>
    <message>
        <location filename="../UI/Yun.py" line="300"/>
        <source>YunWizard-v5.7.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="219"/>
        <source>


Options</source>
        <translation type="obsolete">设置</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="223"/>
        <source>


Documents</source>
        <translation type="obsolete">文档</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="301"/>
        <source>VTM071X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="302"/>
        <source>VTM32030X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="303"/>
        <source>Chip Type</source>
        <translation>芯片选型</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="230"/>
        <source>


New Project</source>
        <translation type="obsolete">创建项目</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="234"/>
        <source>


About</source>
        <translation type="obsolete">关于</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="304"/>
        <source>Keil uVision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="305"/>
        <source>search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="244"/>
        <source>Search Project:</source>
        <translation type="obsolete">搜索项目</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="306"/>
        <source>All Projects</source>
        <translation>所有项目</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="312"/>
        <source>Project </source>
        <translation>项目</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="313"/>
        <source>Tools</source>
        <translation>工具</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="314"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="315"/>
        <source>New Project</source>
        <translation> 创建项目 </translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="316"/>
        <source>Import Project</source>
        <translation> 导入项目 </translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="317"/>
        <source>ICP Programming Tools</source>
        <translation>ICP烧录工具</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="318"/>
        <source>ISP Programming Tool</source>
        <translation>ISP烧录工具</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="319"/>
        <source>SSCOM</source>
        <translation>SSCOM串口工具</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="320"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="309"/>
        <source>Options</source>
        <translation> 设置 </translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="310"/>
        <source>Documents</source>
        <translation>  文档  </translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="311"/>
        <source>About</source>
        <translation> 关于 </translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="307"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="321"/>
        <source>简体中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="322"/>
        <source>繁体中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="323"/>
        <source>Keil Patch</source>
        <translation>Keil补丁</translation>
    </message>
</context>
</TS>
