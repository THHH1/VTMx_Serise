<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>Form</name>
    <message>
        <location filename="../UI/project.py" line="104"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/project.py" line="105"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/project.py" line="106"/>
        <source>PushButton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/project.py" line="107"/>
        <source>open Project</source>
        <translation>打開工程</translation>
    </message>
    <message>
        <location filename="../UI/project.py" line="108"/>
        <source>open Folder</source>
        <translation>打開文件夾</translation>
    </message>
    <message>
        <location filename="../UI/project.py" line="109"/>
        <source>remove Project</source>
        <translation>刪除工程</translation>
    </message>
    <message>
        <location filename="../UI/project.py" line="110"/>
        <source>patch flash</source>
        <translation>Flash補丁</translation>
    </message>
</context>
</TS>
