<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>chip</name>
    <message>
        <location filename="../UI/createVTM.py" line="121"/>
        <source>Choose  Chip Type</source>
        <translation>Choose  Chip Type</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="122"/>
        <source>Create</source>
        <translation>Create</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="123"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="124"/>
        <source>Next</source>
        <translation>Next</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="125"/>
        <source>chip types</source>
        <translation>chip types</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="126"/>
        <source>VTM071</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="127"/>
        <source>Chip Type</source>
        <translation type="unfinished">Chip Type</translation>
    </message>
</context>
</TS>
