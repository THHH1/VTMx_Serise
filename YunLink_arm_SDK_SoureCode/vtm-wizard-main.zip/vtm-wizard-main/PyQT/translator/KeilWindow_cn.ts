<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../UI/keil.py" line="92"/>
        <source>Options</source>
        <translation>設置</translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="93"/>
        <source>Keil uVision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="94"/>
        <source>python3/python executable location (e.g. C:\python3.exe)</source>
        <translation>python3/python可執行位置（如 ：C:\python3.exe）</translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="95"/>
        <source>C:/&quot;Program Files&quot;/Python39/python.exe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="96"/>
        <source>E:/Keil/core/UV4/UV4.exe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="97"/>
        <source>Keil uVersion executable location (e.g. C:\UV4.exe)</source>
        <translation>Keil uVersion可執行位置（如 ：C:\UV4.exe）</translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="98"/>
        <source>Version:</source>
        <translation>版本：</translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="99"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="100"/>
        <source>OK</source>
        <translation>確定</translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="101"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
</context>
</TS>
