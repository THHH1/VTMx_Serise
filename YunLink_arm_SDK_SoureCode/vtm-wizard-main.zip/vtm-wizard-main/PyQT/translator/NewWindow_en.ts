<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../UI/create.py" line="188"/>
        <source>Development Tool</source>
        <translation>Development Tool</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="191"/>
        <source>Keil uVision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="192"/>
        <source>all</source>
        <translation>all</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="193"/>
        <source>Test_Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="194"/>
        <source>E:/Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="121"/>
        <source>    Cancel</source>
        <translation type="obsolete">Cancel</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="122"/>
        <source>    Next</source>
        <translation type="obsolete">Next</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="123"/>
        <source>    Create</source>
        <translation type="obsolete">Create</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="198"/>
        <source>Project Name:</source>
        <translation>Project Name:</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="199"/>
        <source>Directory:</source>
        <translation>Directory:</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="187"/>
        <source>Choose IDE</source>
        <translation>Choose IDE</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="189"/>
        <source>IDE/Toolchain</source>
        <translation>IDE/Toolchain</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="190"/>
        <source>Features</source>
        <translation>Features</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="195"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="196"/>
        <source>Next</source>
        <translation>Next</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="197"/>
        <source>Create</source>
        <translation>Create</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="200"/>
        <source>Back</source>
        <translation>Back</translation>
    </message>
</context>
</TS>
