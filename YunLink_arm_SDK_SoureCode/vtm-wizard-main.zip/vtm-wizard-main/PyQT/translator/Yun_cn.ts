<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>YunWizard</name>
    <message>
        <location filename="../UI/Yun.py" line="300"/>
        <source>YunWizard-v5.7.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="219"/>
        <source>


Options</source>
        <translation type="obsolete">設置</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="223"/>
        <source>


Documents</source>
        <translation type="obsolete">文檔</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="301"/>
        <source>VTM071X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="302"/>
        <source>VTM32030X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="303"/>
        <source>Chip Type</source>
        <translation>芯片選型</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="230"/>
        <source>


New Project</source>
        <translation type="obsolete">創建項目</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="234"/>
        <source>


About</source>
        <translation type="obsolete">關於</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="304"/>
        <source>Keil uVision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="305"/>
        <source>search</source>
        <translation>搜索</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="244"/>
        <source>Search Project:</source>
        <translation type="obsolete">搜索項目</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="306"/>
        <source>All Projects</source>
        <translation>所有項目</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="312"/>
        <source>Project </source>
        <translation>項目</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="313"/>
        <source>Tools</source>
        <translation>工具</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="314"/>
        <source>Language</source>
        <translation>語言</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="315"/>
        <source>New Project</source>
        <translation> 創建項目 </translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="316"/>
        <source>Import Project</source>
        <translation> 導入項目 </translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="317"/>
        <source>ICP Programming Tools</source>
        <translation>ICP燒錄工具</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="318"/>
        <source>ISP Programming Tool</source>
        <translation>ISP燒錄工具</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="319"/>
        <source>SSCOM</source>
        <translation>SSCOM串口工具</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="320"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="309"/>
        <source>Options</source>
        <translation> 設置 </translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="310"/>
        <source>Documents</source>
        <translation>  文檔  </translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="311"/>
        <source>About</source>
        <translation> 關於 </translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="307"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="321"/>
        <source>简体中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="322"/>
        <source>繁体中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="323"/>
        <source>Keil Patch</source>
        <translation>Keil補丁</translation>
    </message>
</context>
</TS>
