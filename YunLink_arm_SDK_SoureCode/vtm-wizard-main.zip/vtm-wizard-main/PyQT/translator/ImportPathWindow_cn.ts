<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>add</name>
    <message>
        <location filename="../UI/importpath.py" line="88"/>
        <source>Import Project</source>
        <translation>導入項目</translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="89"/>
        <source>E:\out\V1.35\Projects\Test_Project\MDK-ARM\Project.uvprojx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="90"/>
        <source>*.uvprojx executable location (e.g. C:\Project.uvprojx)</source>
        <translation>*.uvprojx 可執行位置 (例如：. C:\Project.uvprojx)</translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="91"/>
        <source>Test_Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="92"/>
        <source>Project Name</source>
        <translation>項目名稱</translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="93"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="94"/>
        <source>Import</source>
        <translation>導入</translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="95"/>
        <source>Back</source>
        <translation type="unfinished">返回</translation>
    </message>
</context>
</TS>
