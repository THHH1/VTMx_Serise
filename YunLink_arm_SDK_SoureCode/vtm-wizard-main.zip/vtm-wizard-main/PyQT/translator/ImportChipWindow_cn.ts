<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>chip</name>
    <message>
        <location filename="../UI/importchip.py" line="91"/>
        <source>Choose  Chip Type</source>
        <translation>芯片選型</translation>
    </message>
    <message>
        <location filename="../UI/importchip.py" line="70"/>
        <source>    Cancel</source>
        <translation type="obsolete">取消</translation>
    </message>
    <message>
        <location filename="../UI/importchip.py" line="71"/>
        <source>    Next</source>
        <translation type="obsolete">下一步</translation>
    </message>
    <message>
        <location filename="../UI/importchip.py" line="94"/>
        <source>chip types</source>
        <translation>芯片類型</translation>
    </message>
    <message>
        <location filename="../UI/importchip.py" line="95"/>
        <source>VTM071</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importchip.py" line="96"/>
        <source>Chip Type</source>
        <translation>芯片類型</translation>
    </message>
    <message>
        <location filename="../UI/importchip.py" line="92"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../UI/importchip.py" line="93"/>
        <source>Next</source>
        <translation>下一步</translation>
    </message>
</context>
</TS>
