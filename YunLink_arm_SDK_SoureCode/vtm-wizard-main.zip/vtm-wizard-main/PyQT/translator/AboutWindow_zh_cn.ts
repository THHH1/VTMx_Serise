<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>About</name>
    <message>
        <location filename="../UI/about.py" line="56"/>
        <source>About</source>
        <translation type="unfinished">关于</translation>
    </message>
    <message>
        <location filename="../UI/about.py" line="57"/>
        <source>OK</source>
        <translation type="unfinished">确认</translation>
    </message>
    <message>
        <location filename="../UI/about.py" line="58"/>
        <source>Copyright(c) by</source>
        <translation type="unfinished">  版权所属</translation>
    </message>
</context>
</TS>
