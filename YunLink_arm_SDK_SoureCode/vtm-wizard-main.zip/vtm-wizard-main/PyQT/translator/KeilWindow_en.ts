<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../UI/keil.py" line="92"/>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="93"/>
        <source>Keil uVision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="94"/>
        <source>python3/python executable location (e.g. C:\python3.exe)</source>
        <translation>python3/python executable location (e.g. C:\python3.exe)</translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="95"/>
        <source>C:/&quot;Program Files&quot;/Python39/python.exe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="96"/>
        <source>E:/Keil/core/UV4/UV4.exe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="97"/>
        <source>Keil uVersion executable location (e.g. C:\UV4.exe)</source>
        <translation>Keil uVersion executable location (e.g. C:\UV4.exe)</translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="98"/>
        <source>Version:</source>
        <translation>Version:</translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="99"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="100"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../UI/keil.py" line="101"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
</context>
</TS>
