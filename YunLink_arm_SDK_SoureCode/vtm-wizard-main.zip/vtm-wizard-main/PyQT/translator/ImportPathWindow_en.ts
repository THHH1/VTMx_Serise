<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>add</name>
    <message>
        <location filename="../UI/importpath.py" line="88"/>
        <source>Import Project</source>
        <translation>Import Project</translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="89"/>
        <source>E:\out\V1.35\Projects\Test_Project\MDK-ARM\Project.uvprojx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="90"/>
        <source>*.uvprojx executable location (e.g. C:\Project.uvprojx)</source>
        <translation>*.uvprojx executable location (e.g. C:\Project.uvprojx)</translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="91"/>
        <source>Test_Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="92"/>
        <source>Project Name</source>
        <translation>Project Name</translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="93"/>
        <source>Cancel</source>
        <translation>Cancel</translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="94"/>
        <source>Import</source>
        <translation>Import</translation>
    </message>
    <message>
        <location filename="../UI/importpath.py" line="95"/>
        <source>Back</source>
        <translation type="unfinished">Back</translation>
    </message>
</context>
</TS>
