<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_TW">
<context>
    <name>chip</name>
    <message>
        <location filename="../UI/createVTM.py" line="121"/>
        <source>Choose  Chip Type</source>
        <translation>芯片選型</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="75"/>
        <source>    Create</source>
        <translation type="obsolete">創建</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="76"/>
        <source>    Cancel</source>
        <translation type="obsolete">取消</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="77"/>
        <source>    Next</source>
        <translation type="obsolete">下一步</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="125"/>
        <source>chip types</source>
        <translation>芯片類型</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="126"/>
        <source>VTM071</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="127"/>
        <source>Chip Type</source>
        <translation>芯片類型</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="122"/>
        <source>Create</source>
        <translation>創建</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="123"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../UI/createVTM.py" line="124"/>
        <source>Next</source>
        <translation>下一步</translation>
    </message>
</context>
</TS>
