<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en">
<context>
    <name>YunWizard</name>
    <message>
        <location filename="../UI/Yun.py" line="300"/>
        <source>YunWizard-v5.7.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="219"/>
        <source>


Options</source>
        <translation type="obsolete">Options</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="223"/>
        <source>


Documents</source>
        <translation type="obsolete">Documents</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="301"/>
        <source>VTM071X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="302"/>
        <source>VTM32030X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="303"/>
        <source>Chip Type</source>
        <translation>Chip Type</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="230"/>
        <source>


New Project</source>
        <translation type="obsolete">New Project</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="234"/>
        <source>


About</source>
        <translation type="obsolete">About</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="304"/>
        <source>Keil uVision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="305"/>
        <source>search</source>
        <translation>search</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="244"/>
        <source>Search Project:</source>
        <translation type="obsolete">Search Project</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="306"/>
        <source>All Projects</source>
        <translation>All Projects</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="312"/>
        <source>Project </source>
        <translation>Project</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="313"/>
        <source>Tools</source>
        <translation>Tools</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="314"/>
        <source>Language</source>
        <translation>Language</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="315"/>
        <source>New Project</source>
        <translation>New Project</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="316"/>
        <source>Import Project</source>
        <translation>Import Project</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="317"/>
        <source>ICP Programming Tools</source>
        <translation>ICP Programming Tools</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="318"/>
        <source>ISP Programming Tool</source>
        <translation>ISP Programming Tools</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="319"/>
        <source>SSCOM</source>
        <translation>SSCOM</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="320"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="309"/>
        <source>Options</source>
        <translation>Options</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="310"/>
        <source>Documents</source>
        <translation>Documents</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="311"/>
        <source>About</source>
        <translation>About</translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="307"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="321"/>
        <source>简体中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="322"/>
        <source>繁体中文</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/Yun.py" line="323"/>
        <source>Keil Patch</source>
        <translation>Keil Patch</translation>
    </message>
</context>
</TS>
