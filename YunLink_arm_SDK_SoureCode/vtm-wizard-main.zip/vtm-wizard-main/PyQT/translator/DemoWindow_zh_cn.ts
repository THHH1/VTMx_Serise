<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../UI/demo.py" line="359"/>
        <source>Choose demo</source>
        <translation>选择模块</translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="218"/>
        <source>    Create</source>
        <translation type="obsolete">创建</translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="219"/>
        <source>    Cancel</source>
        <translation type="obsolete">取消</translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="362"/>
        <source>Choose Modeules</source>
        <translation>选择模块</translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="363"/>
        <source>chip</source>
        <translation>芯片</translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="364"/>
        <source>modular</source>
        <translation>模块</translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="365"/>
        <source>CDC_HID_Composite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="366"/>
        <source>Custom_HID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="367"/>
        <source>HID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="368"/>
        <source>MSC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="369"/>
        <source>Virtual_COM_Port</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="370"/>
        <source>TIMER_Timer_and_PWM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="371"/>
        <source>ACMP_DAC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="372"/>
        <source>I2C_EEPROM</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="373"/>
        <source>FLASH_IAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="374"/>
        <source>ADC_Chip_Temperature</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="375"/>
        <source>ADC_Trigger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="376"/>
        <source>TIMER_Breathing_Light</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="377"/>
        <source>ADC_Pin_Loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="378"/>
        <source>TIMER_PWM_and_Capture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="379"/>
        <source>DeepSleep_PowerDown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="380"/>
        <source>MCPWM_Complementary_waveform</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="381"/>
        <source>USART_RX_and_TX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="382"/>
        <source>ADC_ADC_Watchdog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="383"/>
        <source>DAC_DAC0_DAC1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="384"/>
        <source>GPIO_LED_and_Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="385"/>
        <source>ADC_Pin_Interrupt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="386"/>
        <source>SPI_SPI_FLASH</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="387"/>
        <source>RTC_Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="388"/>
        <source>DeepSleep_DeepSleep</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="389"/>
        <source>IWDG_Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="390"/>
        <source>WWDG_Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="391"/>
        <source>V1.35</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="392"/>
        <source>USBV1.0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="360"/>
        <source>Create</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="361"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../UI/demo.py" line="393"/>
        <source>Back</source>
        <translation>返回</translation>
    </message>
</context>
</TS>
