<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../UI/create.py" line="188"/>
        <source>Development Tool</source>
        <translation>编辑器</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="191"/>
        <source>Keil uVision</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="192"/>
        <source>all</source>
        <translation>全部</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="193"/>
        <source>Test_Project</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="194"/>
        <source>E:/Cache</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="121"/>
        <source>    Cancel</source>
        <translation type="obsolete">取消</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="122"/>
        <source>    Next</source>
        <translation type="obsolete">下一步</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="123"/>
        <source>    Create</source>
        <translation type="obsolete">创建</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="198"/>
        <source>Project Name:</source>
        <translation>项目名称：</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="199"/>
        <source>Directory:</source>
        <translation>目录：</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="187"/>
        <source>Choose IDE</source>
        <translation>选择IDE</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="189"/>
        <source>IDE/Toolchain</source>
        <translation>IDE/工具链</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="190"/>
        <source>Features</source>
        <translation>结构</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="195"/>
        <source>Cancel</source>
        <translation>取消</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="196"/>
        <source>Next</source>
        <translation>下一步</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="197"/>
        <source>Create</source>
        <translation>创建</translation>
    </message>
    <message>
        <location filename="../UI/create.py" line="200"/>
        <source>Back</source>
        <translation>返回</translation>
    </message>
</context>
</TS>
